/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package random;

import data.Physician;
import data.PenaltyAssign;
import data.Instance;
import data.FixedAssign;
import data.Lock;
import data.NotPrefLoc;
import java.util.Random;

/**
 *
 * @author Tatiana
 */
public class ParamRandom {
    
    public Instance inst;
    public Random rnd;
    public String infoRnd = "";
        
    public ParamRandom(){
        inst = new Instance();
        rnd = new Random();
        
    }
    
//##############################################################################    
    /** DAYS OF THE INSTANCE.  
     *  Enter de month and the year.
     */
    public void rndMode_DAYS(int month, int year){
        inst.setMonth(month,year);
    }
    

//##############################################################################    
    /** HOLIDAYS.
     *  Enter the days that are holidays.
     */    
    public void rndMode_HOLIDAYS(int holidays[]){
        inst.holidays = holidays;
    }
    
    
//##############################################################################    
    /** LOCATIONS.
     *  Enter the quantity of locations.
     */
    public void rndMode_LOCATIONS(int qty){
        inst.noLocs = qty;
    }
    

//##############################################################################    
    /** PHYSICIANS.
     *  3 types of contracts:
     *      HIGH workload:   200 hours, 24h/48h min/max not business days
     *      LOW workload:    150 hours, 12h/24h min/max not business days
     *  Enter the number of physicians and the percentage of physicians in each type of contract
     */
    public void rndMode_PHYSICIANS(int noPhys, int percHigh, int percMedium, int percLow){
        inst.noPhys = noPhys;
        
        int lowWorkload     = (int) (noPhys* (double) percLow/100);
        int mediumWorkload  = 0;//(int) (noPhys*(double) percMedium/100);
        int highWorkload    = noPhys - mediumWorkload - lowWorkload;  
        
        int noLow = 0, noMedium = 0, noHigh = 0;        
        for(int i=1; i<=inst.noPhys; i++){
            Physician phys = new Physician(i,inst.noLocs);
            
            int rndSel = rnd.nextInt(3)+1;
            
            if((rndSel == 1 && noLow < lowWorkload) || (rndSel == 2 && noMedium >= mediumWorkload) || (rndSel == 3 && noHigh >= highWorkload)) {
                phys.workload = 150;
                phys.idealHours_notWorkDay = 24;
                
                noLow++;
            }
            /*else if((rndSel == 2 && noMedium < mediumWorkload) || (rndSel == 1 && noLow >= lowWorkload) || (rndSel == 3 && noHigh >= highWorkload)){
                phys.workload = 180;
                phys.idealHours_notWorkDay = 36;
                
                noMedium++;
            }*/
            else if((rndSel == 3 && noHigh < highWorkload) || (rndSel == 1 && noLow >= lowWorkload) || (rndSel == 2 && noMedium >= mediumWorkload)){
                phys.workload = 200;
                phys.idealHours_notWorkDay = 48;
                
                noHigh++;
            }
            
            inst.physicians.add(phys);
        }
    }
    
    
//##############################################################################
    /** PHYSICIANS x LOCATIONS.
     *  Enter the percentage of unrestricted locations and the percentage of physicians who are allowed to the location
     */    
    public void rndMode_LOCxPHYS(int percUnr, int percPhysPerm){
        
        int noLocsUnrestricted = (int) (inst.noLocs * (double) percUnr/100);
        int probLoc[] = new int[inst.noLocs+1];

        for(int i=1; i<=inst.noLocs; i++){
            if(noLocsUnrestricted > 0){
                probLoc[i] = 100;
                noLocsUnrestricted--;
            }
            else probLoc[i] = percPhysPerm;
        }
        
        for(int i=0; i<inst.noPhys; i++){
            Physician phys = inst.physicians.get(i);

            for(int j=1; j<=inst.noLocs; j++){
                if(rnd.nextInt(100) <= probLoc[j]){
                    phys.allowLoc[j] = true;
                    phys.noAllowedLocs++;
                }
            }
        }        
    }
    
 
//##############################################################################    
    /** LOCKS.
     *  Enter the probability of a day/shift to be locked.
     */    
    public void rndMode_LOCK(int probLock, boolean allDay){
        
        if(probLock == 0) return;
        
        //int max = (int) Math.round(inst.noPhys/(3*inst.noLocs) * 25);
        
        //Random locks on day/shifts
        for(int i=0; i<inst.noPhys; i++){
            Physician phys = inst.physicians.get(i);
            
            for(int day=inst.firstDay; day<=inst.lastDay; day++){
                //Only it locks a shift of the day, if the physician is not on vacations
                if(!phys.vacation[day] && inst.isWorkDay(day)){
                    
                    if(allDay && rnd.nextInt(100) <= probLock){
                        for(int iSh=1; iSh<=3; iSh++){
                            inst.physicians.get(i).lock[day] = true;
                            inst.locks.add(new Lock(phys.ID,day,iSh));
                        }
                    }
                    else{
                        for(int iSh=1; iSh<=3; iSh++){
                            if(rnd.nextInt(100) <= probLock){
                                inst.physicians.get(i).lock[day] = true;
                                inst.locks.add(new Lock(phys.ID,day,iSh));
                            }
                        }
                    }
                }
            }
        }
    }
    
    
//##############################################################################
    /** FIXED ASSIGNMENTS.
     *  Enter the percentage of the fixed assignments, whereas physicians x days
     */
    public void rndMode_FIXED_byPerc(int perc){
        
        int maxFixed = (int) (inst.noPhys * inst.noDays * (double) perc/100);
        inst.fixedAssign = new int[32][4][inst.noLocs+1];
        
        int noFixed = 0;
        for(int j=inst.noPhys-1; j>=0; j--){
            Physician phys = inst.physicians.get(j);                
            int day = rnd.nextInt(inst.lastDay)+inst.firstDay;
            
            if(!phys.lock[day] && inst.isWorkDay(day)){ //If it is not a lock day
                if(!phys.vacation[day]){ //If it is not a vacation day
                    
                    int iShift = rnd.nextInt(3)+1;
                    int iLoc = rnd.nextInt(inst.noLocs)+1;
                    
                    if(phys.allowLoc[iLoc]){ //If the physician is allowed to the location
                        if((iShift != 3 && !phys.assignNight[day-1]) || iShift == 3){ //If the assignment is valid
                            if(inst.isWorkDay(day)){
                                phys.fixed[day] = true;
                                inst.fixedAssigns.add(new FixedAssign(phys.ID,day,iShift,iLoc));
                                inst.fixedAssign[day][iShift][iLoc]++;
                                if(iShift == 3) phys.assignNight[day] = true;
                                noFixed++;
                            }
                            else{
                                if(iShift == 3){
                                    phys.fixed[day] = true;
                                    inst.fixedAssigns.add(new FixedAssign(phys.ID,day,iShift,iLoc));
                                    inst.fixedAssign[day][iShift][iLoc]++;
                                    phys.assignNight[day] = true;
                                    noFixed++;
                                }
                                else{
                                    phys.fixed[day] = true;
                                    inst.fixedAssigns.add(new FixedAssign(phys.ID,day,1,iLoc)); //SHIFT DAY = 1,2
                                    inst.fixedAssign[day][1][iLoc]++;
                                    phys.assignNight[day] = false;
                                    noFixed++;
                                    
                                    phys.fixed[day] = true;
                                    inst.fixedAssigns.add(new FixedAssign(phys.ID,day,2,iLoc)); //SHIFT DAY = 1,2
                                    inst.fixedAssign[day][2][iLoc]++;
                                    phys.assignNight[day] = false;
                                    noFixed++;
                                }
                            }
                        }
                    }
                }
            }
            
            if(noFixed >= maxFixed) return;
        }
    }
    
    public void rndMode_FIXED_byProb(int prob){
        
        inst.fixedAssign = new int[32][4][inst.noLocs+1];
        
        for(int j=inst.noPhys-1; j>=0; j--){
            Physician phys = inst.physicians.get(j);                
            int day = rnd.nextInt(inst.lastDay)+inst.firstDay;
            
            if(!phys.lock[day] && inst.isWorkDay(day)){ //If it is not a lock day
                if(!phys.vacation[day]){ //If it is not a vacation day
                    
                    int iShift = rnd.nextInt(2)+1;
                    int iLoc = rnd.nextInt(inst.noLocs)+1;
                    
                    if(phys.allowLoc[iLoc]){ //If the physician is allowed to the location
                        if(rnd.nextInt(100) <= prob){
                            if((iShift != 3 && !phys.assignNight[day-1]) || iShift == 3){ //If the assignment is valid
                                if(inst.isWorkDay(day)){
                                    phys.fixed[day] = true;
                                    inst.fixedAssigns.add(new FixedAssign(phys.ID,day,iShift,iLoc));
                                    inst.fixedAssign[day][iShift][iLoc]++;
                                    if(iShift == 3) phys.assignNight[day] = true;
                                }
                                else{
                                    if(iShift == 3){
                                        phys.fixed[day] = true;
                                        inst.fixedAssigns.add(new FixedAssign(phys.ID,day,iShift,iLoc));
                                        inst.fixedAssign[day][iShift][iLoc]++;
                                        phys.assignNight[day] = true;
                                    }
                                    else{
                                        phys.fixed[day] = true;
                                        inst.fixedAssigns.add(new FixedAssign(phys.ID,day,1,iLoc)); //SHIFT DAY = 1,2
                                        inst.fixedAssign[day][1][iLoc]++;
                                        phys.assignNight[day] = false;

                                        phys.fixed[day] = true;
                                        inst.fixedAssigns.add(new FixedAssign(phys.ID,day,2,iLoc)); //SHIFT DAY = 1,2
                                        inst.fixedAssign[day][2][iLoc]++;
                                        phys.assignNight[day] = false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
 

//##############################################################################
    /** PHYSICIANS X PENALTY PER ASSIGNMENT.
     *  Enter the scale of penalty
     *  Enter the percentage of day/shift's which is high preferential
     *  Enter the percentage of day/shift's which is indiferent
     *  Enter the percentage of day/shift's which is high not preferential
     */    
    public void rndMode_NPREFDAYSxPHYS_byPerc(int percNPref, int scale){
        
        int noNPref = (int) (inst.noPhys * inst.noDays * 3 * (double) percNPref/100);
        
        for(int i=0; i<inst.noPhys; i++){
            Physician phys = inst.physicians.get(i);
            for(int day=inst.firstDay; day<=inst.lastDay; day++){
                if(!phys.lock[day] && !phys.vacation[day] && !phys.fixed[day]){ //If it is not a lock day, neither a vacation day, neither a fixed day
                    for(int iSh=1; iSh<=3; iSh++){
                        if(rnd.nextBoolean() && noNPref > 0){
                            inst.notPrefWDSh.add(new PenaltyAssign(i+1,day,iSh,10));//new Random().nextInt(scale)+1));
                            noNPref--;
                        }
                    }
                }
            }
        }
    }
    
    public void rndMode_NPREFDAYSxPHYS_byProb(int probNPref, int scale){
        
        for(int i=0; i<inst.noPhys; i++){
            Physician phys = inst.physicians.get(i);
            for(int day=inst.firstDay; day<=inst.lastDay; day++){
                if(!phys.lock[day] && !phys.vacation[day] && !phys.fixed[day]){ //If it is not a lock day, neither a vacation day, neither a fixed day
                    for(int iSh=1; iSh<=3; iSh++){
                        if(rnd.nextInt(100) <= probNPref){
                            inst.notPrefWDSh.add(new PenaltyAssign(i+1,day,iSh,1));
                        }
                    }
                }
            }
        }
    }
 
    
//##############################################################################    
    /** PHYSICIANS X PREFERENCES PER LOCATION.
     *  Enter the probability of the physician has not preference for the location
     */
    public void rndMode_NPREFLOCxPHYS(int probNA, int weight){
        
        for(int i=0; i<inst.noPhys; i++){
            for(int iLoc=1; iLoc<=inst.noLocs; iLoc++){
                Physician phys = inst.physicians.get(i);
                if(phys.allowLoc[iLoc] && rnd.nextInt(100) <= probNA){
                    inst.notPrefLoc.add(new NotPrefLoc(i+1,iLoc,weight));//rnd.nextInt(weight)+1));
                }
            }
        }
    }
    
    
//##############################################################################
    /** DEMAND.
     *  Enter the minimum and maximum interval for the minimum demand of physicians 
     *  Enter the minimum and maximum interval for the maximum demand of physicians
     */
    
    public void rndMode_REQUIREMENTS(double percMin_wD, double percMin_nwD){
        
        inst.minAssign = new int[inst.noDays+1][5][inst.noLocs+1];
        inst.maxAssign = new int[inst.noDays+1][5][inst.noLocs+1];
        
        for(int iWD=1; iWD<=inst.noDays; iWD++){
            
            int noShifts = 3;
            if(!inst.isWorkDay(iWD)) noShifts = 2;
            
            for(int iShift=1; iShift<=4; iShift++){ //MOR, AFT, NIG, DAY
                //if((inst.isWorkDay(iWD) && (iShift==1 || iShift==2 || iShift ==3)) ||
                    //!inst.isWorkDay(iWD) && (iShift==3 || iShift == 4)){
                    for(int iLoc=1; iLoc<=inst.noLocs; iLoc++){
                        inst.noRequirements++;
                        
                        int minReq = 0;
                        int maxReq = 0;
                        
                        if(inst.isWorkDay(iWD)){
                            minReq = (int) Math.round(inst.noPhys/(3*inst.noLocs) * percMin_wD);
                            maxReq = minReq + 2;
                        }
                        else{
                            minReq = (int) Math.round(inst.noPhys/(2*inst.noLocs) * percMin_nwD);
                            maxReq = minReq + 2;
                        }
                        
                        inst.minAssign[iWD][iShift][iLoc] = minReq;
                        inst.maxAssign[iWD][iShift][iLoc] = maxReq;
                    }
                //}
                
            }
        }
    }
}
