/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package random;

import data.Physician;
import data.PenaltyAssign;
import data.Instance;
import data.Lock;
import data.FixedAssign;
import data.NotPrefLoc;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Tatiana
 */
public class WriteFile {
    
    private Instance inst;
    private final String version = "1.3";
    
    public WriteFile(Instance infoInst, String filename, String infoGen){
        
        inst = infoInst;
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
            
            //Informações da geração aleatória
            bw.write(infoGen);
            
            bw.write("\n");
            
            //MONTH
            bw.write("MONTH = "+inst.year+" "+inst.month+" 1 "+inst.lastDay+"\n\n");
            
            //HOLIDAYS
            bw.write("HOLIDAYS = "+inst.holidays.length+"\n");
            for(int aux : inst.holidays){
                bw.write(aux+"\n");
            }
            bw.write("\n");
            
            //LOCATIONS
            bw.write("LOCATIONS = "+inst.noLocs+"\n");
            for(int i=1; i<=inst.noLocs; i++){
                bw.write(i+" "+"Location"+i+"\n");
            }
            bw.write("\n");
            
            //PHYSICIANS
            bw.write("PHYSICIANS = "+inst.physicians.size()+"\n");
            for(Physician aux : inst.physicians){
                bw.write(aux.ID+" "+"Physician"+aux.ID+" "+aux.workload+" "+aux.idealHours_notWorkDay+" ");
                
                for(int i=1; i<=inst.noLocs; i++){
                    if(i>1) bw.write(",");
                    
                    if(aux.allowLoc[i]) bw.write("1");
                    else bw.write("0");
                }
                bw.write("\n");
            }
            bw.write("\n");
                        
            //FIXED ASSIGNMENTS
            bw.write("FIXED ASSIGNMENTS = "+inst.fixedAssigns.size()+"\n");
            for(FixedAssign fixed : inst.fixedAssigns){
                bw.write(fixed.phys+" "+fixed.day+" "+fixed.shift+" "+fixed.loc+"\n");
            }
            bw.write("\n");
            
            //LOCKS, ABSENCES and VACATIONS
            bw.write("LOCKS = "+(inst.locks.size())+"\n");
            for(Lock lock : inst.locks){
                bw.write(lock.phys+" "+lock.day+" "+lock.shift+"\n");
            }
            bw.write("\n");
                        
            bw.write("NOT PREFERENCE PER LOCATION = "+inst.notPrefLoc.size()+"\n");
            for(NotPrefLoc notPref : inst.notPrefLoc){
                bw.write(notPref.iPhys+" "+notPref.iLoc+" "+notPref.weight+"\n");
            }
            bw.write("\n");
            
            bw.write("PENALTY PER ASSIGN = "+inst.notPrefWDSh.size()+"\n");
            for(PenaltyAssign notPref : inst.notPrefWDSh){
                bw.write(notPref.iPhys+" "+notPref.day+" "+notPref.iShift+" "+notPref.iPenalty+"\n");
            }
            bw.write("\n");
            
            bw.write("REQUIREMENTS = "+inst.noRequirements+"\n");
            for(int iWD=1; iWD<=inst.noDays; iWD++){
                for(int iShift=1; iShift<=3; iShift++){
                    /*if((inst.isWorkDay(iWD) && (iShift==1 || iShift==2 || iShift==3)) ||
                        !inst.isWorkDay(iWD) && (iShift==3 || iShift==4)){*/
                        
                        for(int iLoc=1; iLoc<=inst.noLocs; iLoc++){
                            bw.write(iWD+" "+iShift+" "+iLoc+" "+
                                    inst.minAssign[iWD][iShift][iLoc]+" "+
                                    inst.maxAssign[iWD][iShift][iLoc]+"\n");
                        }
                    //}
                }
            }
            bw.write("\n");
            
            bw.close();
            
        } catch (IOException ex) {
            Logger.getLogger(Instance.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
