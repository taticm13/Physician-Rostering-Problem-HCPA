/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package random;

/**
 *
 * @author Tatiana
 */


public class Parameters {
    
    public static final String NULL = "Null";
    public static final String LOW  = "Low";
    public static final String HIGH = "High";
    
    public String name;
    
    public Parameters(String name, double percMin, int percLock, int percFixed){
        this.name = name;
        setWorkload();
        set_allowLoc();
        set_nPref();
        
        set_requirements(percMin);        
        set_lock(percLock,false);
        set_fixed(percFixed);
        
    }
    
/*  ## WORKLOAD ############################################################# */
    public int workload_percFullTime;    //200 hours and 48 ideal non business days
    public int workload_percParcial;     //120 hours and 24 ideal non business days    
    public void setWorkload(){
        workload_percFullTime   = 80;
        workload_percParcial    = 20;
    }
    
    
/*  ## ALLOWED LOCATIONS #################################################### */
    public int allowLoc_percUnrLocs;
    public int allowLoc_percPhysPerm;    
    public void set_allowLoc(){
        allowLoc_percUnrLocs    = 80;
        allowLoc_percPhysPerm   = 40;
    }
    
    
/*  ## DAY/SHIFT AND LOCATION NON PREFERENTIAL ############################## */
    public int probNPref;    
    public void set_nPref(){
        probNPref = 30;
    }
    
/*  ## LOCK ################################################################# */
    public int lock_probLockDS;
    public boolean lock_allDay;
    
    public void set_lock(int probLock, boolean allDay){
        lock_probLockDS     = probLock;
        lock_allDay         = allDay;
    }
    
    
/*  ## FIXED ################################################################# */
    public String fixed_option;
    public int fixed_prob;   
    public void set_fixed(int prob){
        fixed_prob = prob;
    }
    
      
/*  ## REQUIREMENTS ######################################################### */
    public String req_option;
    public double percMin_wD;
    public double percMin_nwD;   
    public void set_requirements(double percMin){
        req_option = "VAR";        
        /*switch(option){
            case LOW:{
                percMin_wD = 0.50;
                percMin_nwD = 0.25;
            };break;
            case HIGH:{
                percMin_wD = 0.75;
                percMin_nwD = 0.375;
            };break;
            default:
        }*/
        
        percMin_wD = percMin;
        percMin_nwD = percMin/2;
    }
    
    public String printParameters(){
        String info = "";
        
        info += "# RANDOM GENERATION (version 7)\n\n";
        
        info += "# HOLIDAYS: National and regional holidays\n\n";
        
        info += "# CONTRACTS: \n";
        info += "# "+workload_percFullTime+"% of the physicians with FULL TIME workload (200 hours, 48h ideal not business days)\n";
        info += "# "+workload_percParcial +"% of the physicians with PARTIAL workload   (150 hours, 24h ideal not business days)\n\n";
        
        info += "# ALLOWED LOCATIONS: \n";
        info += "# "+allowLoc_percUnrLocs+"% of locations are unrestricted\n";
        info += "# "+allowLoc_percPhysPerm+"% probability of physician having authorization in restricted location\n\n";
        
        info += "# NON PREFERENTIAL:\n";
        info += "# "+probNPref+"% probability of a day/shift being non-preferential\n";
        info += "# "+probNPref+"% probability of a location being non-preferential\n\n";
        
        info += "# REQUIREMENTS:\n";
        info += "# Minimum on working days = noPhys/(noShift*noLocs)*"+percMin_wD+"\n";
        info += "# Minimum on non-working days = noPhys/(noShift*noLocs)*"+percMin_nwD+"\n";
        info += "# Maximum = min + 6\n\n";
                
        info += "# LOCK ASSIGNMENTS:\n";
        info += "# "+lock_probLockDS+"% probability of a physician having a lock on the day/shift\n";
        info += "# It locks all shifts of the same day = "+lock_allDay+"\n\n";
        
        info += "# FIXED ASSIGNMENTS:\n";
        info += "# "+fixed_prob+"% probability of an assignments being fixed \n\n";
        
        
        return info;
    }
}
