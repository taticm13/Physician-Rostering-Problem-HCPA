/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author Tatiana
 */
public class PenaltyAssign {
    public int iPhys;
    public int day;
    public int iShift;
    public int iPenalty;
    
    public PenaltyAssign(int aPhys, int aWD, int aShift, int aPenalty){
        iPhys = aPhys;
        day = aWD;
        iShift = aShift;
        iPenalty = aPenalty;
    }
}
