/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author Tatiana
 */
public class FixedAssign {
    public int phys;
    public int day;
    public int shift;
    public int loc;

    public FixedAssign(int aPhys, int aDay, int aShift, int aLoc){
        phys = aPhys;
        day = aDay;
        shift = aShift;
        loc = aLoc;
    }
}
