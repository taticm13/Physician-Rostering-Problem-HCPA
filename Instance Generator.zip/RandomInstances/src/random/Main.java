/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package random;

import java.util.ArrayList;

/**
 *
 * @author Tatiana
 */
public class Main {
    
    public static void main(String[] args) {
        
        
        //It generates instances for all months of the 2019
        String version = "16";
        String path_RANDOM = "Instances\\Version "+version+"\\";
        
        int holidaysPerMonth [][] = new int[13][];
            holidaysPerMonth[1] = new int[]{1};
            holidaysPerMonth[2] = new int[]{};
            holidaysPerMonth[3] = new int[]{5};
            holidaysPerMonth[4] = new int[]{19,21};
            holidaysPerMonth[5] = new int[]{1};
            holidaysPerMonth[6] = new int[]{20};
            holidaysPerMonth[7] = new int[]{};
            holidaysPerMonth[8] = new int[]{};
            holidaysPerMonth[9] = new int[]{7,20};
            holidaysPerMonth[10] = new int[]{12};
            holidaysPerMonth[11] = new int[]{2,15};
            holidaysPerMonth[12] = new int[]{25};
        
        int list_noPhys[] = new int[]{50,100,150};
        int list_noLocs[] = new int[]{3};
        int list_months[] = new int[]{1};
        ArrayList<Parameters> listParam = parametersV2();
        
        //Number of physicians (in real instances of HCPA, until 50 physicians)
        
        for(int noPhys : list_noPhys){
            for(int noLocs : list_noLocs){
                for(int iMonth : list_months){
                    for(Parameters param : listParam){
                        System.out.println("noPhys="+noPhys+" ,noLocs="+noLocs+", param="+param.name);
                        String mes = Integer.toString(iMonth);
                        if(mes.length() == 1) mes = "0"+mes;

                        create(noPhys,noLocs,iMonth,holidaysPerMonth[iMonth],path_RANDOM+"Instance"+param.name+"_2019"+mes+"_",param);
                    }
                }
            }
        }
    }
    
    
    public static ArrayList<Parameters> parametersV2(){
        
        ArrayList<Parameters> listParam = new ArrayList<>();
        
        listParam.add(new Parameters("H01",0.80,10,0));
        listParam.add(new Parameters("H02",0.80,10,0));
        listParam.add(new Parameters("H03",0.80,10,0));
        listParam.add(new Parameters("L01",0.10,60,30));
        listParam.add(new Parameters("L02",0.10,60,30));
        listParam.add(new Parameters("L03",0.10,60,30));
        
        return listParam;
    }
    
    
    private static void create(int noPhys, int noLocs, int month, int holidays[], String nomeBase, Parameters param){
        ParamRandom rndInst = new ParamRandom();
        
       
        //mês, ano, número de dias
        rndInst.rndMode_DAYS(month,2019);
        
        //quantidade de feriados
        rndInst.rndMode_HOLIDAYS(holidays);
        
        //número de áreas
        rndInst.rndMode_LOCATIONS(noLocs);        
        
        //Quantidade de médicos e percentual por tipo de contrato (200,150,120)
        rndInst.rndMode_PHYSICIANS(noPhys,param.workload_percFullTime,0,param.workload_percParcial);
        
        //Probabilidade do médico possuir cada área
        rndInst.rndMode_LOCxPHYS(param.allowLoc_percUnrLocs,param.allowLoc_percPhysPerm);
        
        //rndInst.rndMode_VACATION(param.lock_percPhysVac);
        rndInst.rndMode_LOCK(param.lock_probLockDS,param.lock_allDay);
        rndInst.rndMode_FIXED_byProb(param.fixed_prob);
        rndInst.rndMode_NPREFDAYSxPHYS_byProb(param.probNPref,1);
        rndInst.rndMode_NPREFLOCxPHYS(param.probNPref,1);
        rndInst.rndMode_REQUIREMENTS(param.percMin_wD,param.percMin_nwD);
        
        new WriteFile(rndInst.inst,nomeBase+noPhys+"P"+noLocs+"L.txt",param.printParameters());
        
    }
    
}
