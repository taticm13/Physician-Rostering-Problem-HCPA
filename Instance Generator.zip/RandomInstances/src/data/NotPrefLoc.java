/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author Tatiana
 */
public class NotPrefLoc {
    public int iPhys;
    public int iLoc;
    public int weight;

    public NotPrefLoc(int aPhys, int aLoc, int aWeight){
        iPhys = aPhys;
        iLoc = aLoc;
        weight = aWeight;
    }
}
